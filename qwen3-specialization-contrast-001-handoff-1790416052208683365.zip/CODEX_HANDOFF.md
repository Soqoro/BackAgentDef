Specialization fixed-bank ablation; not full PACT. Review ZIP omits weights/optimizer tensors. Full snapshots required for resume. No automatic follow-up.
